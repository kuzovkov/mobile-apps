package com.dexterous.flutterlocalnotifications.models;

public enum NotificationChannelAction {
    CreateIfNotExists,
    Update
}
